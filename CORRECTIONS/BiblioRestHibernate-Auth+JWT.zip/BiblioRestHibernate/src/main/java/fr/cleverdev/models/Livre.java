package fr.cleverdev.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table( name="livre" )
public class Livre {

	@Id
	@GeneratedValue( strategy=GenerationType.IDENTITY )
	private Long id;
	
	@Column( nullable=false )
	private String titre;
	
	@Column( name="nb_pages" )
	private int nbPages;
	
	@ManyToOne( fetch=FetchType.LAZY )
	private Auteur auteur;
	
	@OneToOne( fetch=FetchType.LAZY )
	private Couverture couverture;
	
	@ManyToMany (cascade={CascadeType.PERSIST, CascadeType.MERGE})
	@JoinTable(
		name="livre_genre",
		joinColumns = { @JoinColumn(name="livre_id") },
		inverseJoinColumns = { @JoinColumn(name="genre_id") }
	)
	private List<Genre> genres = new ArrayList<Genre>();
	
	
	/* Constructeurs */
	public Livre() {
		
	}
	
	public Livre(String titre, int nbPages) {
		this.titre = titre;
		this.nbPages = nbPages;
	}

	
	/* Getters and Setters */
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitre() {
		return titre;
	}

	public void setTitre(String titre) {
		this.titre = titre;
	}

	public int getNbPages() {
		return nbPages;
	}

	public void setNbPages(int nbPages) {
		this.nbPages = nbPages;
	}

	public Auteur getAuteur() {
		return auteur;
	}

	public void setAuteur(Auteur auteur) {
		this.auteur = auteur;
	}

	public Couverture getCouverture() {
		return couverture;
	}

	public void setCouverture(Couverture couverture) {
		this.couverture = couverture;
	}

	public List<Genre> getGenres() {
		return genres;
	}

	public void setGenres(List<Genre> genres) {
		this.genres = genres;
	}
	
	public void addGenre(Genre genre) {
		this.genres.add(genre);
		genre.getLivres().add(this);
	}
	
	public void removeGenre(Genre genre) {
		this.genres.remove(genre);
		genre.getLivres().remove(this);
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Livre) {
			return this.id == ((Livre) obj).id;
		}
		return false;
	}

}
