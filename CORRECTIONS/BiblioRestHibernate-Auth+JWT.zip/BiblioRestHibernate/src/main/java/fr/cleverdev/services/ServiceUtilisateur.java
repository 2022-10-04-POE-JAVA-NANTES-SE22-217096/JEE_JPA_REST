package fr.cleverdev.services;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;

import com.google.gson.JsonObject;

import fr.cleverdev.dao.DaoException;
import fr.cleverdev.dao.impl.DaoUtilisateur;
import fr.cleverdev.models.Utilisateur;
import fr.cleverdev.utils.HashPassword;
import fr.cleverdev.utils.TokenJWT;

public class ServiceUtilisateur {
	
	private DaoUtilisateur dao;
	
	public ServiceUtilisateur() {
		dao = new DaoUtilisateur();
	}
	
	
	public void create(JsonObject data) throws ServiceException, NoSuchAlgorithmException, IOException {
		String nom = null, prenom = null, nomUtilisateur = null, motDePasse = null;
		
		try {
			nom = ServiceTools.getStringParameter(data, "nomUtilisateur", 2, 255);	
			prenom = ServiceTools.getStringParameter(data, "prenomUtilisateur", 3, 255);	
			
			nomUtilisateur = ServiceTools.getStringParameter(data, "loginUtilisateur", 6, 255);	
			
			motDePasse = ServiceTools.getStringParameter(data, "passwordUtilisateur", 1, 255, "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
            //Le mot de passe doit contenir au moins 8 caract�res, dont une lettre majuscule, une lettre minuscule, un chiffre et un caract�re sp�cial. 
			
			
			if(nomUtilisateur == null)
				throw new ServiceException("Le champ loginUtilisateur est obligatoire.");
			
			if(motDePasse == null)
				throw new ServiceException("Le champ passwordUtilisateur est obligatoire.");
			
			Utilisateur utilisateur = dao.find(nomUtilisateur);
			if(utilisateur != null)
				throw new ServiceException("Le loginUtilisateur est d�ja utilis�.");
			
			
			utilisateur = new Utilisateur(nom, prenom, nomUtilisateur, HashPassword.hashPass(motDePasse));
			dao.create(utilisateur);
			
		} catch(DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}
	
	
	
	public String login(JsonObject data) throws ServiceException, NoSuchAlgorithmException, IOException {
		String nomUtilisateur = null, motDePasse = null;
		
		nomUtilisateur = ServiceTools.getStringParameter(data, "loginUtilisateur", 6, 255);	

		motDePasse = ServiceTools.getStringParameter(data, "passwordUtilisateur", 1, 255, "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
        //Le mot de passe doit contenir au moins 8 caract�res, dont une lettre majuscule, une lettre minuscule, un chiffre et un caract�re sp�cial. 
		
		if(nomUtilisateur == null)
			throw new ServiceException("Le champ loginUtilisateur est obligatoire.");
		
		if(motDePasse == null)
			throw new ServiceException("Le champ passwordUtilisateur est obligatoire.");
		
		
		Utilisateur utilisateur = dao.find(nomUtilisateur, HashPassword.hashPass(motDePasse));
		if(utilisateur == null)
			throw new ServiceException("Les identifiants ne sont pas correct.");
			
		
		String token = TokenJWT.generateJWT(nomUtilisateur, 60);

		JsonObject dataReturn = new JsonObject();
		dataReturn.addProperty("token", token);
		dataReturn.addProperty("login", nomUtilisateur);

		return dataReturn.toString();
	}
	
}
