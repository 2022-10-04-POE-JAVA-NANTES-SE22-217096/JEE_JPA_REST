package fr.cleverdev.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class Configuration {

	public static Properties getConfig() throws IOException {

		ClassLoader classLoader = Thread.currentThread().getContextClassLoader();			
		
		InputStream ficProps = classLoader.getResourceAsStream("/fr/cleverdev/utils/config.properties");
		Properties properties = new Properties();
	
		properties.load(ficProps);
        
        return properties;
	}
	
}
