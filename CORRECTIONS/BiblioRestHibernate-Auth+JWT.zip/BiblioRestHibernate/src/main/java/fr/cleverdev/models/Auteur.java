package fr.cleverdev.models;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table( name="auteur" )
public class Auteur {

	@Id
	@GeneratedValue( strategy=GenerationType.IDENTITY )
	private Long id;
	
	@Column( nullable=false )
	private String prenom;
	
	@Column( nullable=false )
	private String nom;
	
	private String telephone;
	
	private String email;
	
	@OneToMany(mappedBy="auteur", cascade=CascadeType.ALL)
	private List<Livre> livres = new ArrayList<Livre>();
	
	
	public Auteur() {
		
	}
	
	public Auteur(String prenom, String nom, String telephone, String email) {
		this.prenom = prenom;
		this.nom = nom;
		this.telephone = telephone;
		this.email = email;
	}

	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Livre> getLivres() {
		return livres;
	}

	public void setLivres(List<Livre> livres) {
		this.livres = livres;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Auteur) {
			return this.id == ((Auteur) obj).id;
		}
		return false;
	}

}
