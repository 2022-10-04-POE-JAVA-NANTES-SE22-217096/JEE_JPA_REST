package fr.cleverdev.dao.impl;

import fr.cleverdev.dao.DaoObject;
import fr.cleverdev.models.Livre;

public class DaoLivre extends DaoObject<Livre> {

	public DaoLivre() {
		super(Livre.class);
	}

}
