package fr.cleverdev.servlets.filters;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fr.cleverdev.utils.Authentification;

/**
 * Servlet Filter implementation class AuthFilter
 */
@WebFilter(
		urlPatterns = { "/auteur", "/couverture", "/genre", "/livre" }
		)
public class AuthFilter implements Filter {

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;

		if (httpServletRequest.getMethod().equalsIgnoreCase("GET")){
			chain.doFilter(request, response);
		} else {
			if(Authentification.isAuthentificated(httpServletRequest)) {
				chain.doFilter(request, response);
			} else {
				httpServletResponse.setCharacterEncoding("UTF-8");
				httpServletResponse.setStatus(401);
				httpServletResponse.getWriter().write("Jeton de connection invalide.");
			}
			
		}
	}

}
