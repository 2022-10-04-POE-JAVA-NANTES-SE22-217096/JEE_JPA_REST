package fr.cleverdev.dao.impl;

import javax.persistence.NoResultException;
import javax.persistence.Query;

import fr.cleverdev.dao.DaoObject;
import fr.cleverdev.models.Utilisateur;

public class DaoUtilisateur extends DaoObject<Utilisateur> {

	public DaoUtilisateur() {
		super(Utilisateur.class);
	}
	
	public Utilisateur find(String nomUtilisateur) {
		Utilisateur utilisateur = null;

		try {
			Query query = getFactory().getEntityManager().createQuery("SELECT u FROM Utilisateur u WHERE u.nomUtilisateur=:nomUtilisateur", Utilisateur.class);
			query.setParameter("nomUtilisateur", nomUtilisateur);
			
			utilisateur = (Utilisateur) query.getSingleResult();		
		} catch(NoResultException e) {
			e.printStackTrace();
		} finally {
			getFactory().releaseEntityManager();
		}
		
		return utilisateur;
	}
	
	public Utilisateur find(String nomUtilisateur, String motDePasse) {
		Utilisateur utilisateur = null;

		try {
			Query query = getFactory().getEntityManager().createQuery("SELECT u FROM Utilisateur u WHERE u.nomUtilisateur=:nomUtilisateur AND u.motDePasse=:motDePasse", Utilisateur.class);
			query.setParameter("nomUtilisateur", nomUtilisateur);
			query.setParameter("motDePasse", motDePasse);
			
			utilisateur = (Utilisateur) query.getSingleResult();		
		} catch(NoResultException e) {
			e.printStackTrace();
		} finally {
			getFactory().releaseEntityManager();
		}
		
		return utilisateur;
	}

}
