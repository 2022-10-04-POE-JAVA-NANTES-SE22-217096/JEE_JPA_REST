package fr.cleverdev.services;

import com.google.gson.JsonObject;

import fr.cleverdev.dao.DaoException;
import fr.cleverdev.dao.impl.DaoGenre;
import fr.cleverdev.models.Genre;

public class ServiceGenre {

	private DaoGenre dao;
	
	public ServiceGenre() {
		dao = new DaoGenre();
	}
	
	
	public String find(long id) throws ServiceException {
		Genre genre = dao.find(id);
		
		if(genre == null)
			throw new ServiceException("Le genre n'existe pas. Id : "+id);
		
		return ServiceTools.getSuperJson().toJson(genre);
	}

	
	public String list() throws ServiceException {
		return ServiceTools.getSuperJson().toJson(dao.list());	
	}
	
	public void create(JsonObject data) throws ServiceException {
		String nom = null;
		
		try {
			nom = ServiceTools.getStringParameter(data, "nomGenre", 2, 255);	

			if(nom == null)
				throw new ServiceException("Le champ nomGenre est obligatoire.");

			dao.create(new Genre(nom));
		} catch (DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}

	public void update(JsonObject data) throws ServiceException {
		String id = null, nom = null;
		
		try {
			id = ServiceTools.getStringParameter(data, "idGenre", 0, 50, "^\\d+$");
			nom = ServiceTools.getStringParameter(data, "nomGenre", 2, 255);	

			if(id == null)
				throw new ServiceException("Le champ idGenre est obligatoire.");
			
			if(nom == null)
				throw new ServiceException("Le champ nomGenre est obligatoire.");
			

			Genre genre = dao.find(Long.parseLong(id));
			if(genre == null)
				throw new ServiceException("Le genre n'existe pas. Id : "+id);
			
			genre.setNom(nom);
			
			dao.update(genre);
		} catch(NumberFormatException e) {
			throw new ServiceException("Le format du param�tre idGenre n'est pas bon.");
		} catch (DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}

	public void delete(long id) throws ServiceException {
		try {
			dao.delete(id);
		} catch (DaoException e) {
			throw new ServiceException("Le genre n'existe pas. Id : "+id);
		}
	}
	
}
