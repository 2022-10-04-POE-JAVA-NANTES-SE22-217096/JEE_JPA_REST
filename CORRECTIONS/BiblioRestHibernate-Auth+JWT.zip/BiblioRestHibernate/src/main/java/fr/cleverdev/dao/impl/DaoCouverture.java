package fr.cleverdev.dao.impl;

import fr.cleverdev.dao.DaoObject;
import fr.cleverdev.models.Couverture;

public class DaoCouverture extends DaoObject<Couverture> {

	public DaoCouverture() {
		super(Couverture.class);
	}

}
