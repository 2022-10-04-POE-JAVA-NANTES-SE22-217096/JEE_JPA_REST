package fr.cleverdev.services.adapters;

import java.lang.reflect.Type;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

import fr.cleverdev.models.Genre;
import fr.cleverdev.models.Livre;

public class LivreAdapter implements JsonSerializer<Livre> {

	@Override
	public JsonElement serialize(Livre arg0, Type arg1, JsonSerializationContext arg2) {
		JsonObject json = new JsonObject();
		json.addProperty("id", arg0.getId());
		json.addProperty("titre", arg0.getTitre());
		json.addProperty("nbPages", arg0.getNbPages());

		if(arg0.getAuteur() != null) {
			JsonObject auteurJson = new JsonObject();
			auteurJson.addProperty("id", arg0.getAuteur().getId());
			auteurJson.addProperty("nom", arg0.getAuteur().getNom());
			auteurJson.addProperty("prenom", arg0.getAuteur().getPrenom());
			
			json.add("auteur", auteurJson);
		}
		
		if(arg0.getCouverture() != null) {
			JsonObject couvertureJson = new JsonObject();
			couvertureJson.addProperty("id", arg0.getCouverture().getId());
			couvertureJson.addProperty("description", arg0.getCouverture().getDescription());
			
			json.add("couverture", couvertureJson);
		}
		
		JsonArray genresJson = new JsonArray();
		JsonObject genreJson;
		for(Genre genre : arg0.getGenres()) {
			genreJson = new JsonObject();
			genreJson.addProperty("id", genre.getId());
			genreJson.addProperty("nom", genre.getNom());
			
			genresJson.add(genreJson);
		}
		json.add("genres", genresJson);
	
		return json;
	}
	
	

}
