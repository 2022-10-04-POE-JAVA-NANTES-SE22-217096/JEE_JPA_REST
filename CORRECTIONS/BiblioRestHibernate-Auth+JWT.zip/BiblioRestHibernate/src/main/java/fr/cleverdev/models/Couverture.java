package fr.cleverdev.models;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PreRemove;
import javax.persistence.Table;

@Entity
@Table( name="couverture" )
public class Couverture {

	@Id
	@GeneratedValue( strategy=GenerationType.IDENTITY )
	private Long id;
	
	@Column( nullable=false )
	private String description;
	
	@OneToOne( mappedBy="couverture", fetch=FetchType.LAZY )
	private Livre livre;
	
	
	@PreRemove
	private void preRemove() {
	    if(this.livre != null) {
	    	this.livre.setCouverture(null);
	    }
	}
	
	public Couverture() {
		
	}
	
	public Couverture(String description) {
		this.description = description;
	}

	
	
	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Livre getLivre() {
		return livre;
	}

	public void setLivre(Livre livre) {
		this.livre = livre;
	}
	
	
	@Override
	public boolean equals(Object obj) {
		if(obj instanceof Couverture) {
			return this.id == ((Couverture) obj).id;
		}
		return false;
	}

}
