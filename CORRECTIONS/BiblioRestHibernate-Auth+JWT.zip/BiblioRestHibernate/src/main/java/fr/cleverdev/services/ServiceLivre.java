package fr.cleverdev.services;

import com.google.gson.JsonObject;

import fr.cleverdev.dao.DaoException;
import fr.cleverdev.dao.impl.DaoAuteur;
import fr.cleverdev.dao.impl.DaoCouverture;
import fr.cleverdev.dao.impl.DaoGenre;
import fr.cleverdev.dao.impl.DaoLivre;
import fr.cleverdev.models.Auteur;
import fr.cleverdev.models.Couverture;
import fr.cleverdev.models.Genre;
import fr.cleverdev.models.Livre;

public class ServiceLivre {

	private DaoLivre dao;
	private DaoAuteur daoAuteur;
	private DaoCouverture daoCouverture;
	private DaoGenre daoGenre;
	
	public ServiceLivre() {
		dao = new DaoLivre();
		daoAuteur = new DaoAuteur();
		daoCouverture = new DaoCouverture();
		daoGenre = new DaoGenre();
	}
	
	
	public String find(long id) throws ServiceException {
		Livre livre = dao.find(id);
		
		if(livre == null)
			throw new ServiceException("Le livre n'existe pas. Id : "+id);
		
		return ServiceTools.getSuperJson().toJson(livre);
	}

	
	public String list() throws ServiceException {
		return ServiceTools.getSuperJson().toJson(dao.list());	
	}
	
	public void create(JsonObject data) throws ServiceException {
		String titre = null, nbPages = null, idAuteur = null, idCouverture = null;
		int nbPagesParse = -1;
		Auteur auteur = null;
		Couverture couverture = null;
		
		try {
			titre = ServiceTools.getStringParameter(data, "titreLivre", 2, 255);	
			nbPages = ServiceTools.getStringParameter(data, "nbPagesLivre", 1, 255, "^\\d+$");	
			idAuteur = ServiceTools.getStringParameter(data, "idAuteur", 0, 50, "^\\d+$");
			idCouverture = ServiceTools.getStringParameter(data, "idCouverture", 0, 50, "^\\d+$");
			
			if(titre == null)
				throw new ServiceException("Le champ titreLivre est obligatoire.");
			
			
			if(idAuteur != null) {
				auteur = daoAuteur.find(Long.parseLong(idAuteur));
				if(auteur == null)
					throw new ServiceException("L'auteur n'existe pas. Id : "+idAuteur);
			}
			
			if(idCouverture != null) {
				couverture = daoCouverture.find(Long.parseLong(idCouverture));
				if(couverture == null)
					throw new ServiceException("La couverture n'existe pas. Id : "+idCouverture);
				
				if(couverture.getLivre() != null)
					throw new ServiceException("La couverture est d�ja associ� au livre d'id : "+couverture.getLivre().getId());
			}
			
			
			if(nbPages != null)
				nbPagesParse = Integer.parseInt(nbPages);
			
			Livre livre = new Livre(titre, nbPagesParse);
			livre.setAuteur(auteur);
			livre.setCouverture(couverture);
			
			dao.create(livre);
			

		} catch (DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}

	public void update(JsonObject data) throws ServiceException {
		String id = null, titre = null, nbPages = null, idAuteur = null, idCouverture = null;
		int nbPagesParse = -1;
		Auteur auteur = null;
		Couverture couverture = null;
		
		try {
			id = ServiceTools.getStringParameter(data, "idLivre", 0, 50, "^\\d+$");
			titre = ServiceTools.getStringParameter(data, "titreLivre", 2, 255);	
			nbPages = ServiceTools.getStringParameter(data, "nbPagesLivre", 0, 255, "^\\d+$");	
			idAuteur = ServiceTools.getStringParameter(data, "idAuteur", 0, 50, "^\\d+$");
			idCouverture = ServiceTools.getStringParameter(data, "idCouverture", 0, 50, "^\\d+$");
			
			if(id == null)
				throw new ServiceException("Le champ idLivre est obligatoire.");
			
			if(titre == null)
				throw new ServiceException("Le champ titreLivre est obligatoire.");
			
			
			if(idAuteur != null) {
				auteur = daoAuteur.find(Long.parseLong(idAuteur));
				if(auteur == null)
					throw new ServiceException("L'auteur n'existe pas. Id : "+idAuteur);
			}
			
			if(idCouverture != null) {
				couverture = daoCouverture.find(Long.parseLong(idCouverture));
				if(couverture == null)
					throw new ServiceException("La couverture n'existe pas. Id : "+idCouverture);
				
				if(couverture.getLivre() != null && couverture.getLivre().getId() != Long.parseLong(id))
					throw new ServiceException("La couverture est d�ja associ� au livre d'id : "+couverture.getLivre().getId());
			}
			
			
			if(nbPages != null)
				nbPagesParse = Integer.parseInt(nbPages);
			

			Livre livre = dao.find(Long.parseLong(id));
			if(livre == null)
				throw new ServiceException("Le livre n'existe pas. Id : "+id);
			
			livre.setTitre(titre);
			livre.setNbPages(nbPagesParse);
			livre.setAuteur(auteur);
			livre.setCouverture(couverture);
			
			dao.update(livre);
		} catch(NumberFormatException e) {
			throw new ServiceException("Le format du param�tre idLivre n'est pas bon.");
		} catch (DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}

	public void delete(long id) throws ServiceException {
		try {
			dao.delete(id);
		} catch (DaoException e) {
			throw new ServiceException("Le livre n'existe pas. Id : "+id);
		}
	}
	
	
	public void addGenre(long idLivre, long idGenre) throws ServiceException {
		Livre livre = dao.find(idLivre);
		if(livre == null)
			throw new ServiceException("Le livre n'existe pas. Id : "+idLivre);
		
		Genre genre = daoGenre.find(idGenre);
		if(genre == null)
			throw new ServiceException("Le genre n'existe pas. Id : "+idGenre);
		
		if(livre.getGenres().contains(genre))
			throw new ServiceException("Le genre est d�ja associ� au livre.");
		
		
		try {
			livre.addGenre(genre);
			dao.update(livre);
		} catch (DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}
	
	public void removeGenre(long idLivre, long idGenre) throws ServiceException {
		Livre livre = dao.find(idLivre);
		if(livre == null)
			throw new ServiceException("Le livre n'existe pas. Id : "+idLivre);
		
		Genre genre = daoGenre.find(idGenre);
		if(genre == null)
			throw new ServiceException("Le genre n'existe pas. Id : "+idGenre);
		
		if(!livre.getGenres().contains(genre))
			throw new ServiceException("Le genre n'est pas associ� au livre.");
		
		try {
			livre.removeGenre(genre);
			dao.update(livre);
		} catch (DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}
	
}
