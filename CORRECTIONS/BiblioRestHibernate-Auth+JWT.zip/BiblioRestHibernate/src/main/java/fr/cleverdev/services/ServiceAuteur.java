package fr.cleverdev.services;

import com.google.gson.JsonObject;

import fr.cleverdev.dao.DaoException;
import fr.cleverdev.dao.impl.DaoAuteur;
import fr.cleverdev.models.Auteur;

public class ServiceAuteur {

	private DaoAuteur dao;
	
	public ServiceAuteur() {
		dao = new DaoAuteur();
	}
	
	
	public String find(long id) throws ServiceException {
		Auteur auteur = dao.find(id);
		
		if(auteur == null)
			throw new ServiceException("L'auteur n'existe pas. Id : "+id);
		
		return ServiceTools.getSuperJson().toJson(auteur);
	}

	
	public String list() throws ServiceException {
		return ServiceTools.getSuperJson().toJson(dao.list());	
	}
	
	public void create(JsonObject data) throws ServiceException {
		String nom = null, prenom = null, telephone = null, email = null;
		
		try {
			nom = ServiceTools.getStringParameter(data, "nomAuteur", 2, 255);	
			prenom = ServiceTools.getStringParameter(data, "prenomAuteur", 3, 255);	
			telephone = ServiceTools.getStringParameter(data, "telephoneAuteur", 4, 255, "^\\d+$");	
			email = ServiceTools.getStringParameter(data, "emailAuteur", 1, 255, "([^.@]+)(\\.[^.@]+)*@([^.@]+\\.)+([^.@]+)");	
			
			if(nom == null)
				throw new ServiceException("Le champ nomAuteur est obligatoire.");
			
			if(prenom == null)
				throw new ServiceException("Le champ prenomAuteur est obligatoire.");
			
			dao.create(new Auteur(prenom, nom, telephone, email));
		} catch (DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}

	public void update(JsonObject data) throws ServiceException {
		String id = null, nom = null, prenom = null, telephone = null, email = null;
		
		try {
			id = ServiceTools.getStringParameter(data, "idAuteur", 0, 50, "^\\d+$");
			nom = ServiceTools.getStringParameter(data, "nomAuteur", 2, 255);	
			prenom = ServiceTools.getStringParameter(data, "prenomAuteur", 3, 255);	
			telephone = ServiceTools.getStringParameter(data, "telephoneAuteur", 4, 255, "^\\d+$");	
			email = ServiceTools.getStringParameter(data, "emailAuteur", 1, 255, "([^.@]+)(\\.[^.@]+)*@([^.@]+\\.)+([^.@]+)");	
			
			if(id == null)
				throw new ServiceException("Le champ idAuteur est obligatoire.");
			
			if(nom == null)
				throw new ServiceException("Le champ nomAuteur est obligatoire.");
			
			if(prenom == null)
				throw new ServiceException("Le champ prenomAuteur est obligatoire.");

			Auteur auteur = dao.find(Long.parseLong(id));
			if(auteur == null)
				throw new ServiceException("L'auteur n'existe pas. Id : "+id);
			
			auteur.setNom(nom);
			auteur.setPrenom(prenom);
			auteur.setTelephone(telephone);
			auteur.setEmail(email);
			
			dao.update(auteur);
		} catch(NumberFormatException e) {
			throw new ServiceException("Le format du param�tre idAuteur n'est pas bon.");
		} catch (DaoException e) {
			throw new ServiceException("Erreur DAO.");
		}
	}

	public void delete(long id) throws ServiceException {
		try {
			dao.delete(id);
		} catch (DaoException e) {
			throw new ServiceException("L'auteur n'existe pas. Id : "+id);
		}
	}
	
}
