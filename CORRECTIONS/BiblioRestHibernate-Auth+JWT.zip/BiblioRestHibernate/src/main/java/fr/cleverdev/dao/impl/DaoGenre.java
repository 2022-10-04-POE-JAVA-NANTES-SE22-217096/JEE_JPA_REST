package fr.cleverdev.dao.impl;

import fr.cleverdev.dao.DaoObject;
import fr.cleverdev.models.Genre;

public class DaoGenre extends DaoObject<Genre> {

	public DaoGenre() {
		super(Genre.class);
	}

}
