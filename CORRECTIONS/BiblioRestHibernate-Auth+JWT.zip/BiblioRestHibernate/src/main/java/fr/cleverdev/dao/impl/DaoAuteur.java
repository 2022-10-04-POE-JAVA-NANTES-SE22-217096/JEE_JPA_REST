package fr.cleverdev.dao.impl;

import fr.cleverdev.dao.DaoObject;
import fr.cleverdev.models.Auteur;

public class DaoAuteur extends DaoObject<Auteur> {

	public DaoAuteur() {
		super(Auteur.class);
	}
	
}
