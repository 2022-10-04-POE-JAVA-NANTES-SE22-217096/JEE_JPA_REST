package fr.cleverdev.utils;

import javax.servlet.http.HttpServletRequest;

public class Authentification {

	public static boolean isAuthentificated(HttpServletRequest request) {
		boolean isAuthentificated = false;
		
		if(request.getHeader("Authorization") != null) {
			String token = request.getHeader("Authorization").replaceAll("Bearer ", "");
			if(TokenJWT.verifyJWT(token)) {
				isAuthentificated = true;
			}
		}
		
		return isAuthentificated;
	}
	
}
